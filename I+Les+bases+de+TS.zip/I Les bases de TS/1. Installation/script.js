"use strict";
var str = "Hello World";
function foo() {
    return "Hello World";
}
console.log("Hello World");
