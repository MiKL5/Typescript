let str : string = "Hello World" 

function foo() {
    return "Hello World"
}

console.log("Hello World");
