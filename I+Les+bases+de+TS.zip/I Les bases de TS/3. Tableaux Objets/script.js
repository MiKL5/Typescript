"use strict";
// const fruits = ['fraise', 'pomme']
// fruits.push("cerises")
// console.log(fruits);
// const mixedArray = [1, 'txt', [1,2,3]]
// let nums : number [];
// nums.push(1) // erreur
// nums = [1,2,3]
// let nums2 : number [] = []
// nums2.push(2)
// let random : any []; 
// random = [true, false, true]
// Objets
var car = {
    name: "Audi",
    model: "A1",
    km: 70000
};
// car.name = 4 // erreur
// let profile : {
//     name: string, 
//     age: number,
//     hobbies: string[]
// }
// profile = {
//     name: "John",
//     age: 85,
//     hobbies: []
// }
// let user : {
//     name: string,
//     age: number,
//     favFood: string[],
//     data: any
// } = {
//     name: "Joe",
//     age: 45,
//     favFood: ['pasta', 'cheese'],
//     data: 50
// }
var obj;
obj = { name: "Enzo" };
