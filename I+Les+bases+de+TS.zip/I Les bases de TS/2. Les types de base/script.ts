let str = "str"
let num = 5
let array = []
let obj = {
    a: 5
}
let toggle = true

let anything;
let randomNumber : number;

const conversion = (celsius : number) => {
    return (celsius * 9/5) + 32;
}


console.log(conversion(50));
