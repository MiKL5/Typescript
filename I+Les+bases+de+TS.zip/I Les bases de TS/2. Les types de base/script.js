"use strict";
var str = "str";
var num = 5;
var array = [];
var obj = {
    a: 5
};
var toggle = true;
var anything;
var randomNumber;
var conversion = function (celsius) {
    return (celsius * 9 / 5) + 32;
};
console.log(conversion(50));
