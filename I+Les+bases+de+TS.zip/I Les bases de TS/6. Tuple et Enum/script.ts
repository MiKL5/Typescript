// Tuple 

let tuple : [boolean, number]
tuple = [false, 20]


// Enum

// const Roles = {
//     JAVASCRIPT: 1,
//     CSS: 2,
//     REACT: 3
// }
// console.log(Roles.JAVASCRIPT);

enum Roles {JAVASCRIPT = 1, CSS, REACT}

console.log(Roles);
