"use strict";
var code;
code = "5";
var arr;
arr = [1000, false];
var foo = function (param) {
    console.log(param);
};
foo('Test');
function getID(id) {
    return id;
}
console.log(getID(100));
var firstElement = {
    x: 50,
    y: 150,
    id: 999,
    visible: false,
};
